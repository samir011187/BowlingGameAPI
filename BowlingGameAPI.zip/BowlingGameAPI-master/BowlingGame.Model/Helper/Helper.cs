﻿using System;
using System.Collections.Generic;
using System.Text;

namespace BowlingGame.Model.Helper
{
    public static class Helper
    {

        /// <summary>
        /// Maximum number of Frames allowed - default
        /// </summary>
        public const int MaxFrameCount = 10;

        /// <summary>
        /// Number of pins that each Frame should start with -default
        /// </summary>
        public const int StartingPinCount = 10;

        /// <summary>
        /// For strike Number of next rolls look ahead 
        /// </summary>
        public const int StrikeBonusNexrRollsCount = 2;

        /// <summary>
        /// For Spare Number of next rolls look ahead 
        /// </summary>
        public const int SpareBonusNexrRollsCount = 1;

    }
}
