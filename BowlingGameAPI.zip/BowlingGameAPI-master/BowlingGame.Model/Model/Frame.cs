﻿using System;
using System.Collections.Generic;
using System.Text;

namespace BowlingGame.Model.Model
{
    public class Frame
    {
        /// <summary>
        /// How many pins have been knocked down in each roll
        /// </summary>
        public List<int> Rolls { get; set; } = new List<int>();
        /// <summary>
        /// each frame score
        /// </summary>
        public int frameScore { get; set; }

        /// <summary>
        /// Total Score of a Game
        /// </summary>
        public int TotalScore { get; set; }


    }
}
