﻿using System;
using System.Collections.Generic;
using System.Text;

namespace BowlingGame.Model.Model
{
    /// <summary>
    /// Response Class 
    /// </summary>
    public class BowlingGameResponse
    {
        public IEnumerable<int> frameWiseScore { get; set; }
        public int totalScore { get; set; }
    }
}
