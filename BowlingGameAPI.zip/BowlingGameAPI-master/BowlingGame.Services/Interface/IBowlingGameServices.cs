﻿using BowlingGame.Model.Model;
using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;

namespace BowlingGame.Services.Interface
{
    public interface IBowlingGameServices
    {
        Task<BowlingGameResponse> GetBowlingScore(int[][] sequence);
     
    }
}
