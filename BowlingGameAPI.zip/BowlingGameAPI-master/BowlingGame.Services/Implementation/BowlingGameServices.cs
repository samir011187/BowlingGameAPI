﻿using BowlingGame.Model.Helper;
using BowlingGame.Model.Model;
using BowlingGame.Services.Interface;
using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;
using System.Linq;

namespace BowlingGame.Services.Implementation
{
    public class BowlingGameServices : IBowlingGameServices
    {
        public async Task<BowlingGameResponse> GetBowlingScore(int[][] sequence)
        {

            List<Frame> frames = new List<Frame>();

            foreach (var tt in sequence)
            {
                Frame frame = new Frame();
                foreach (var pp in tt)
                {
                    frame.Rolls.Add(pp);
                }
                frames.Add(frame);
            }

            int result = CalculateScore(frames);

            BowlingGameResponse response = new BowlingGameResponse();

            response.frameWiseScore = frames.Select(x => x.frameScore).ToList();
            response.totalScore = result;

            return await Task.FromResult(response);
        }

        /// <summary>
        /// private method , no need expose complex logic
        /// </summary>
        /// <param name="frames"></param>
        /// <returns></returns>
        private int CalculateScore(List<Frame> frames)
        {
            int totalScore = 0;
            for (var frameIndex = 0; frameIndex < frames.Count; frameIndex++)
            {
                var frame = frames[frameIndex];
                var frameScore = 0;
                var bonusScore = 0;
                var isStrike = false;

                // cap the roll index to 2 to avoid over-counting points if the last frame has bonus rolls
                var maxRollIndex = frame.Rolls.Count < 2 ? frame.Rolls.Count : 2;

                for (var rollIndex = 0; rollIndex < maxRollIndex; rollIndex++)
                {
                    var result = frame.Rolls[rollIndex];
                    frameScore += result;

                    // calculate bonus score for a strike
                    if (result == Helper.StartingPinCount)
                    {
                        isStrike = true;

                        //look 2 rolls ahead
                        bonusScore += CalculateStrikeBonus(frameIndex, frames);
                        break;
                    }
                }

                // calculate bonus score for a spare
                if (!isStrike && frameScore == Helper.StartingPinCount)
                {
                    // look 1 roll ahead
                    bonusScore += CalculateSpareBonus(frameIndex, frames);
                }

                totalScore += frameScore + bonusScore;
                frames[frameIndex].frameScore = totalScore;
            }

            return totalScore;
        }



        /// <summary>
        /// function to calculate Strike Bonus
        /// </summary>
        /// <param name="frameIndex"></param>
        /// <param name="frames"></param>
        /// <returns></returns>
        private int CalculateStrikeBonus(int frameIndex, List<Frame> frames)
        {
            int StrikeBonusNexrRollsCount = Helper.StrikeBonusNexrRollsCount;
            int framecounter = 1;
            int RollCounter = 0;
            var bonusPoints = 0;

            // check if strike is in the last frame
            if (frameIndex + framecounter == frames.Count)
            {
                framecounter = 0; /// add to the same frame
                RollCounter++;  // starte itrating over next roll
            }

            for (int i = 0; i < StrikeBonusNexrRollsCount; i++)
            {

                if (!(frames[frameIndex + framecounter].Rolls.Count > i))
                {
                    //itrate over next frame
                    frameIndex++;
                    //reset counter for next frame
                    RollCounter = 0;
                }
                bonusPoints += frames[frameIndex + framecounter].Rolls[RollCounter];
                RollCounter++;
            }

            return bonusPoints;
        }

        /// <summary>
        /// function to calculate spare bonus
        /// </summary>
        /// <param name="frameIndex"></param>
        /// <param name="frames"></param>
        /// <returns></returns>
        private int CalculateSpareBonus(int frameIndex, List<Frame> frames)
        {
            int SpareBonusNexrRollsCount = Helper.SpareBonusNexrRollsCount;
            int framecounter = 1;
            int RollCounter = 0;
            var bonusPoints = 0;

            // check if spare is in the last frame
            if (frameIndex + framecounter == frames.Count)
            {
                framecounter = 0; /// add to the same frame
                RollCounter++;  // starte itrating over next roll
            }

            for (int i = 0; i < SpareBonusNexrRollsCount; i++)
            {

                if (!(frames[frameIndex + framecounter].Rolls.Count > i))
                {
                    //itrate over next frame
                    frameIndex++;
                    //reset counter for next frame
                    RollCounter = 0;
                }
                bonusPoints += frames[frameIndex + framecounter].Rolls[RollCounter];
                RollCounter++;
            }

            return bonusPoints;

        }

    }
}
