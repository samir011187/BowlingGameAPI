﻿
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using System;
using System.Collections.Generic;
using System.Text;
using Xunit;
using BowlingGameAPI.Controllers;
using BowlingGame.Services.Interface;
using BowlingGame.Model.Model;
using Microsoft.Extensions.Configuration;
using BowlingGameScore.Test;
using BowlingGame.Services.Implementation;

namespace BowlingScore.Test.BowlingScore
{
   
    public class GetBowlingScore
    {

        private readonly BowlingGameController _bowlingGameController;
        private readonly ILogger<BowlingGameController> _logger;
        private readonly IBowlingGameServices _bowlingGameServices;
        private readonly IConfiguration _iConfiguration;
        public GetBowlingScore()
        {
            _iConfiguration = TestHelper.GetIConfigurationRoot();
            _bowlingGameServices = new BowlingGameServices();
            _bowlingGameController = new BowlingGameController(_logger, _bowlingGameServices);
        }

        /// <summary>
        /// 
        /// </summary>
       [Fact]
        public async void GetBowlingScoreWhenAllStrike()
        {
            //Assign
            

            int[][] seq = new int[][]{ new []{ 10 }, new[] { 10 }, new[] { 10 }, new[] { 10 }, new[] { 10 },
                                       new []{ 10 }, new []{ 10 }, new []{ 10 }, new []{ 10 }, new []{ 10,10,10 } };

            //Act
            var result = await _bowlingGameController.GetBowlingScore(seq);
            var response = result.Value;

            //Assert   
            Assert.Equal(300, response.totalScore);
          

        }

        /// <summary>
        /// 
        /// </summary>
        [Fact]
        public async void GetBowlingScoreWhenAllSpare()
        {
            //Assign
            int[][] seq = new int[][]{ new []{ 5,5 }, new[] {8,2 }, new[] {9,1 }, new[] {7,3 }, new[] { 8,1 },
                                       new []{ 6,4 }, new []{ 9,1}, new []{ 7,3 }, new []{6,4 }, new []{ 4, 5 } };

            //Act
            var result = await _bowlingGameController.GetBowlingScore(seq);
            var response = result.Value;

            //Assert   
            Assert.Equal(156, response.totalScore);

        }

        [Fact]
        public async void GetBowlingScoreWithCombination()
        {
            //Assign
            int[][] seq = new int[][]{ new []{ 10 }, new[] {10 }, new[] {7,3 }, new[] { 8,2 }, new[] {10 },
                                       new []{9,1 }, new []{10}, new []{ 10 }, new []{10 }, new []{ 10, 7, 3 } };

            //Act
            var result = await _bowlingGameController.GetBowlingScore(seq);
            var response = result.Value;

            //Assert   
            Assert.Equal(232, response.totalScore);

        }
    }
}
