using Microsoft.Extensions.Configuration;
using System;
using System.IO;
using Xunit;

namespace BowlingGameScore.Test
{
    /// <summary>
    /// this class is for setting some default Configurations
    /// </summary>
    public static class TestHelper
    {
        public static IConfigurationRoot GetIConfigurationRoot()
        {
           
            string fullPath = Directory.GetCurrentDirectory();
            return new ConfigurationBuilder()
                .SetBasePath(fullPath)
                .AddJsonFile("appsettings.json", optional: true)
                .AddEnvironmentVariables()
                .Build();
        }

    }
}
