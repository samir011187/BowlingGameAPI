AS backend Exercise, I have created Web API that will calculate the Bowling Game Score

1. "GetBowlingScore" API service method will give you Total Game Score (with each frame score as well) 

2.I have added the swagger page for better understaning and testing.

3. To run the project , follow below steps
	3.1. Unzip the rar file and open the solution file in Visual Studio.
	3.2. once you run the project , swagger page will open.
	3.3. To test api, pass below sequens of pin bowling in body of the request 
	     [[4,3],[10],[4,5],[1,3],[0,4],[2,5],[8,0],[9,1],[6,2],[2,3]]
	3.4. Once you execute the method, you will get the result.
	  