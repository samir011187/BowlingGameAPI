﻿using BowlingGame.Model.Model;
using BowlingGame.Services.Interface;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace BowlingGameAPI.Controllers
{
    [ApiController]
    [Route("[controller]")]
    public class BowlingGameController : ControllerBase
    {


        private readonly ILogger<BowlingGameController> _logger;
        private readonly IBowlingGameServices _bowlingGameServices;
        public BowlingGameController(ILogger<BowlingGameController> logger, IBowlingGameServices bowlingGameServices)
        {
            _logger = logger;
            _bowlingGameServices = bowlingGameServices;
        }

        [HttpPost]
        [Route("GetBowlingScore")]
        public async Task<ActionResult<BowlingGameResponse>> GetBowlingScore([FromBody] int[][] sequence)
        {
            try
            {
                var score = await _bowlingGameServices.GetBowlingScore(sequence);
                return score;
            }
            catch (Exception ex)
            {
                _logger.LogError("Error:" + ex.Message + ex.StackTrace);
                return BadRequest();

            }

        }
    }
}
